package com.freak.flutter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var counter = 0
        var button: Button
        var button1: Button
        var button2: Button
        var textView: TextView
        button1=findViewById(R.id.button1)
        textView = findViewById(R.id.text)
        button = findViewById(R.id.button)
        button2 = findViewById(R.id.button2)

        button.setOnClickListener {
            counter++
            textView.text=counter.toString()

        }
        button1.setOnClickListener {
            if (counter>0){
                counter--
                textView.text=counter.toString()
            }
        }
        button2.setOnClickListener {
            counter = 0
            textView.text=counter.toString()
        }
    }
}