package com.freak.clickme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
Button btnC;
Button btnE;
Button btnI;
Button btnF;
TextView txtView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnC = (Button)findViewById(R.id.btnc);
        btnE = (Button)findViewById(R.id.btne);
        btnI = (Button)findViewById(R.id.btni);
        btnF = (Button)findViewById(R.id.btnf);
        txtView = (TextView)findViewById(R.id.txt);
        btnC.setOnClickListener(this);
        btnE.setOnClickListener(this);
        btnI.setOnClickListener(this);
        btnF.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.btnc){
            txtView.setText("7478831242");
        }
        if(view.getId()==R.id.btne){
            txtView.setText("555ramjaiswal@gmail.com");
        }
        if(view.getId()==R.id.btni){
            txtView.setText("_jaiswal_ram_2910");
        }
        if(view.getId()==R.id.btnf){
            txtView.setText("Ram Jaiswal");
        }
    }
}